Imports System
Imports System.Windows.Forms
Imports System.Drawing
Public Class Form1
    Inherits Form
    Private Label1 As Label, Label2 As Label, Text1 As TextBox
    Private GroupBox1 As GroupBox, GroupBox2 As GroupBox
    Private Option1 As RadioButton, Option2 As RadioButton
    Private Check1 As CheckBox, Check2 As CheckBox, Check3 As CheckBox, Check4 As CheckBox
    Private WithEvents Button1 As Button
    Public Sub New()
        Me.Text = "作业4-3" : Me.StartPosition = FormStartPosition.CenterScreen
        Me.FormBorderStyle = FormBorderStyle.FixedSingle : Me.MaximizeBox = False
        Me.ClientSize = New Size(520, 360)
        Label1 = New Label() With {.Text = "请输入姓名", .Left = 40, .Top = 30, .AutoSize = True, .Font = New Font("Microsoft YaHei UI", 10.0F)}
        Text1 = New TextBox() With {.Left = 160, .Top = 28, .Width = 200}
        GroupBox1 = New GroupBox() With {.Text = "请选择性别", .Left = 40, .Top = 70, .Width = 180, .Height = 100}
        Option1 = New RadioButton() With {.Text = "男", .Left = 20, .Top = 30, .Checked = True}
        Option2 = New RadioButton() With {.Text = "女", .Left = 20, .Top = 60}
        GroupBox1.Controls.AddRange(New Control() {Option1, Option2})
        GroupBox2 = New GroupBox() With {.Text = "请选择爱好", .Left = 260, .Top = 70, .Width = 200, .Height = 140}
        Check1 = New CheckBox() With {.Text = "音乐", .Left = 20, .Top = 30}
        Check2 = New CheckBox() With {.Text = "绘画", .Left = 20, .Top = 60}
        Check3 = New CheckBox() With {.Text = "运动", .Left = 20, .Top = 90}
        Check4 = New CheckBox() With {.Text = "写作", .Left = 20, .Top = 120}
        GroupBox2.Controls.AddRange(New Control() {Check1, Check2, Check3, Check4})
        Button1 = New Button() With {.Text = "确定", .Left = 200, .Top = 240, .Width = 100}
        Label2 = New Label() With {.Left = 40, .Top = 300, .Width = 420, .Height = 30, .BorderStyle = BorderStyle.FixedSingle, .TextAlign = ContentAlignment.MiddleLeft}
        Controls.AddRange(New Control() {Label1, Text1, GroupBox1, GroupBox2, Button1, Label2})
    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If Text1.Text.Trim() = "" Then MessageBox.Show("请输入姓名！", "提示") : Exit Sub
        If Option1.Checked Then
            Label2.Text = Text1.Text & " 是一个男孩。他的爱好是："
        Else
            Label2.Text = Text1.Text & " 是一个女孩。她的爱好是："
        End If
        If Check1.Checked Then Label2.Text &= "音乐 "
        If Check2.Checked Then Label2.Text &= "绘画 "
        If Check3.Checked Then Label2.Text &= "运动 "
        If Check4.Checked Then Label2.Text &= "写作 "
    End Sub
End Class
Module Module1
    <STAThread()> Sub Main() : Application.EnableVisualStyles() : Application.SetCompatibleTextRenderingDefault(False) : Application.Run(New Form1()) : End Sub
End Module
