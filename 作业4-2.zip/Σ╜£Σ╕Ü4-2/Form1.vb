Imports System
Imports System.Windows.Forms
Imports System.Drawing
Public Class Form1
    Inherits Form
    Private WithEvents cmdAdd As Button, WithEvents cmdDel As Button, WithEvents cmdMod As Button
    Private WithEvents cmdOK As Button, WithEvents cmdCancel As Button, WithEvents cmdEnd As Button
    Public Sub New()
        Me.Text = "作业4-2" : Me.StartPosition = FormStartPosition.CenterScreen
        Me.FormBorderStyle = FormBorderStyle.FixedSingle : Me.MaximizeBox = False
        Me.ClientSize = New Size(400, 280)
        cmdAdd = New Button() With {.Text = "增加", .Left = 60, .Top = 40, .Width = 80}
        cmdDel = New Button() With {.Text = "删除", .Left = 160, .Top = 40, .Width = 80}
        cmdMod = New Button() With {.Text = "修改", .Left = 260, .Top = 40, .Width = 80}
        cmdOK = New Button() With {.Text = "确定", .Left = 100, .Top = 120, .Width = 80, .Enabled = False}
        cmdCancel = New Button() With {.Text = "取消", .Left = 220, .Top = 120, .Width = 80, .Enabled = False}
        cmdEnd = New Button() With {.Text = "退出", .Left = 160, .Top = 200, .Width = 80}
        Controls.AddRange(New Control() {cmdAdd, cmdDel, cmdMod, cmdOK, cmdCancel, cmdEnd})
    End Sub
    Private Sub enabled1() : cmdOK.Enabled = True : cmdCancel.Enabled = True : cmdAdd.Enabled = False : cmdDel.Enabled = False : cmdMod.Enabled = False : cmdEnd.Enabled = False : End Sub
    Private Sub enabled2() : cmdOK.Enabled = False : cmdCancel.Enabled = False : cmdAdd.Enabled = True : cmdDel.Enabled = True : cmdMod.Enabled = True : cmdEnd.Enabled = True : End Sub
    Private Sub cmdAdd_Click(sender As Object, e As EventArgs) Handles cmdAdd.Click : enabled1() : End Sub
    Private Sub cmdDel_Click(sender As Object, e As EventArgs) Handles cmdDel.Click : enabled1() : End Sub
    Private Sub cmdMod_Click(sender As Object, e As EventArgs) Handles cmdMod.Click : enabled1() : End Sub
    Private Sub cmdOK_Click(sender As Object, e As EventArgs) Handles cmdOK.Click : enabled2() : End Sub
    Private Sub cmdCancel_Click(sender As Object, e As EventArgs) Handles cmdCancel.Click : enabled2() : End Sub
    Private Sub cmdEnd_Click(sender As Object, e As EventArgs) Handles cmdEnd.Click : End : End Sub
End Class
Module Module1
    <STAThread()> Sub Main() : Application.EnableVisualStyles() : Application.SetCompatibleTextRenderingDefault(False) : Application.Run(New Form1()) : End Sub
End Module
