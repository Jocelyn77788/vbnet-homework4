Imports System
Imports System.Reflection
<Assembly: AssemblyTitle("作业4-2")>
<Assembly: AssemblyDescription("")>
<Assembly: AssemblyCompany("")>
<Assembly: AssemblyProduct("作业4-2")>
<Assembly: AssemblyVersion("1.0.0.0")>
