Imports System
Imports System.Windows.Forms
Imports System.Drawing
Public Class Form1
    Inherits Form
    Private Label1 As Label, Label2 As Label, Label3 As Label
    Private Text1 As TextBox, Combo1 As ComboBox
    Private WithEvents Button1 As Button
    Public Sub New()
        Me.Text = "作业4-4" : Me.StartPosition = FormStartPosition.CenterScreen
        Me.FormBorderStyle = FormBorderStyle.FixedSingle : Me.MaximizeBox = False
        Me.ClientSize = New Size(420, 300)
        Label1 = New Label() With {.Text = "请输入姓名", .Left = 40, .Top = 40, .AutoSize = True, .Font = New Font("Microsoft YaHei UI", 10.0F)}
        Text1 = New TextBox() With {.Left = 150, .Top = 38, .Width = 180}
        Label2 = New Label() With {.Text = "请输入等级", .Left = 40, .Top = 90, .AutoSize = True, .Font = New Font("Microsoft YaHei UI", 10.0F)}
        Combo1 = New ComboBox() With {.Left = 150, .Top = 88, .Width = 180, .DropDownStyle = ComboBoxStyle.DropDownList}
        Combo1.Items.AddRange(New Object() {"优秀", "良好", "中等", "及格", "不及格"}) : Combo1.SelectedIndex = 0
        Button1 = New Button() With {.Text = "确定", .Left = 150, .Top = 140, .Width = 100}
        Label3 = New Label() With {.Left = 40, .Top = 200, .Width = 320, .Height = 40, .BorderStyle = BorderStyle.FixedSingle, .TextAlign = ContentAlignment.MiddleLeft}
        Controls.AddRange(New Control() {Label1, Text1, Label2, Combo1, Button1, Label3})
    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If Text1.Text.Trim() = "" Then MessageBox.Show("请输入姓名！", "提示") : Exit Sub
        Select Case Combo1.SelectedIndex
            Case 0 : Label3.Text = Text1.Text & " 的考评结果为：90-100"
            Case 1 : Label3.Text = Text1.Text & " 的考评结果为：80-89"
            Case 2 : Label3.Text = Text1.Text & " 的考评结果为：70-79"
            Case 3 : Label3.Text = Text1.Text & " 的考评结果为：60-69"
            Case 4 : Label3.Text = Text1.Text & " 的考评结果为：0-59"
        End Select
    End Sub
End Class
Module Module1
    <STAThread()> Sub Main() : Application.EnableVisualStyles() : Application.SetCompatibleTextRenderingDefault(False) : Application.Run(New Form1()) : End Sub
End Module
