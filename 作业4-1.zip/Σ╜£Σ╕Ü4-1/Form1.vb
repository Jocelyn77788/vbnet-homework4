Imports System
Imports System.Windows.Forms
Imports System.Drawing
Public Class Form1
    Inherits Form
    Private Label1 As Label, Label2 As Label, Text1 As TextBox
    Private WithEvents Button1 As Button, WithEvents Button2 As Button
    Public Sub New()
        Me.Text = "作业4-1" : Me.StartPosition = FormStartPosition.CenterScreen
        Me.FormBorderStyle = FormBorderStyle.FixedSingle : Me.MaximizeBox = False
        Me.ClientSize = New Size(520, 260)
        Label1 = New Label() With {.Text = "请输入姓名", .Font = New Font("Microsoft YaHei UI", 11.0F), .AutoSize = True, .Left = 60, .Top = 40}
        Text1 = New TextBox() With {.Left = Label1.Left + 120, .Top = Label1.Top - 2, .Width = 200}
        Button1 = New Button() With {.Text = "显示姓名", .Left = 120, .Top = 110, .Width = 110}
        Button2 = New Button() With {.Text = "问候", .Left = Button1.Right + 20, .Top = Button1.Top, .Width = 110}
        Label2 = New Label() With {.Left = 60, .Top = 170, .Width = 380, .Height = 28, .BorderStyle = BorderStyle.FixedSingle, .TextAlign = ContentAlignment.MiddleLeft}
        Controls.AddRange(New Control() {Label1, Text1, Button1, Button2, Label2})
    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click : Label2.Text = Text1.Text : End Sub
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click : Label2.Text = Text1.Text & " 你好！" : End Sub
End Class
Module Module1
    <STAThread()> Sub Main() : Application.EnableVisualStyles() : Application.SetCompatibleTextRenderingDefault(False) : Application.Run(New Form1()) : End Sub
End Module
