Imports System
Imports System.Reflection
<Assembly: AssemblyTitle("作业4-1")>
<Assembly: AssemblyDescription("")>
<Assembly: AssemblyCompany("")>
<Assembly: AssemblyProduct("作业4-1")>
<Assembly: AssemblyVersion("1.0.0.0")>
